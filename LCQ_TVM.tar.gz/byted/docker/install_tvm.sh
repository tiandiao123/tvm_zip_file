cd /opt/tiger
git clone --recursive https://code.byted.org/data/tvm tvm
cd /opt/tiger/tvm

mkdir -p build
cp cmake/config.cmake build
cd build
echo set\(USE_LLVM ON\) >> config.cmake
echo set\(USE_CUDA ON\) >> config.cmake
echo set\(USE_CUDNN ON\) >> config.cmake
cmake ..
make -j64
cd ..
