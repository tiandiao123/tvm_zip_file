#!/bin/bash
echo "I am in install_bernard_cli shell script"

export PIP_INDEX_URL=https://bytedpypi.byted.org/simple/
pip install -r /opt/tiger/bernard_cli/cli/requirements.txt
pip install --user /opt/tiger/bernard_cli/cli
export BERNARD_DEFAULT_AUTH_METHOD=jwt_key
echo "my key is : "
echo c99c1f6cb807c254ee58a0426415694f714b24dc
export BERNARD_JWT_KEY=c99c1f6cb807c254ee58a0426415694f714b24dc
export PATH=~/.local/bin:$PATH

pip install -r /opt/tiger/ByteTunner/requirements.txt
pip install cloudpickle
apt-get install zip
apt-get install unzip
