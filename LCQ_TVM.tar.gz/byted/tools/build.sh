#!/bin/bash

mkdir -p build
cp cmake/config.cmake build
cd build
sed -i 's/USE_CUDA OFF/USE_CUDA ON/g' config.cmake
sed -i 's/USE_LLVM OFF/USE_LLVM ON/g' config.cmake
sed -i 's/USE_GRAPH_RUNTIME_DEBUG OFF/USE_GRAPH_RUNTIME_DEBUG ON/g' config.cmake
sed -i 's/USE_VM_PROFILER OFF/USE_VM_PROFILER ON/g' config.cmake
cmake ..
make -j64
cd ..

pip install torch==1.8.0
pip install torchvision==0.2.2

echo "finished updating pytorch version"
