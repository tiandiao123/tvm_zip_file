#!/usr/bin/env python

# Licensed to the Apache Software Foundation (ASF) under one
# or more contributor license agreements.  See the NOTICE file
# distributed with this work for additional information
# regarding copyright ownership.  The ASF licenses this file
# to you under the Apache License, Version 2.0 (the
# "License"); you may not use this file except in compliance
# with the License.  You may obtain a copy of the License at
#
#   http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing,
# software distributed under the License is distributed on an
# "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
# KIND, either express or implied.  See the License for the
# specific language governing permissions and limitations
# under the License.
"""Test script for tf op module"""
import tempfile
import os
import logging
import tensorflow as tf
import numpy as np
import tvm
import tvm.testing
from tvm import te
from tvm import relay
from tvm.contrib import tf_op
from tvm.contrib import graph_runtime

def test_use_tvmdso_op():
    """main test function"""

    def build_export_graph():
        """relay build & export graph"""
        x = relay.var("x", shape=(10, 5))
        y = relay.var("y", shape=(1, 5))
        z = relay.add(x, y)
        z = relay.exp(z)
        func = relay.Function([x, y], z)
        x_data = np.random.rand(10, 5).astype("float32")
        y_data = np.random.rand(1, 5).astype("float32")
        params = {"y": y_data}
        graph, lib, params = relay.build(tvm.IRModule.from_expr(func), target="cuda", params=params)
        mod = graph_runtime.create(graph, lib, ctx=tvm.gpu(0))
        mod.set_input(**params)
        mod.set_input(x=x_data)
        mod.run()
        res = mod.get_output(0).asnumpy()
        ref_res = np.exp(y_data + x_data)
        tvm.testing.assert_allclose(res, ref_res, atol=1e-5, rtol=1e-5)

        # export to tempdir
        tvm_assets = ["mod.so", "graph.json", "params"]
        export_dir = tempfile.mkdtemp("tvm_export")
        lib.export_library(os.path.join(export_dir, tvm_assets[0]))
        with open(os.path.join(export_dir, tvm_assets[1]), 'w') as fout:
            fout.write(graph)
        with open(os.path.join(export_dir, tvm_assets[2]), 'wb') as fout:
            fout.write(relay.save_param_dict(params))

        return export_dir

    def test_tf_run(session, lib_path, tf_device):
        """test add lib with TensorFlow wrapper"""
        module = tf_op.GraphModule()

        x = tf.placeholder("float32", shape=[10, 5])
        y = tf.placeholder("float32", shape=[1, 5])
        x_data = np.random.rand(10, 5).astype("float32")
        y_data = np.random.rand(1, 5).astype("float32")
        feed_dict = {x: x_data, y: y_data}

        expect = np.exp(y_data + x_data)
        output_shapes = [expect.shape]
        output_dtypes = [expect.dtype]

        tvm_assets = ["mod.so", "graph.json", "params"]
        assets = [os.path.join(lib_path, i) for i in tvm_assets]
        init_op = module.init((x.shape, y.shape), *assets)
        output_tensors = module.run(x, y, output_shapes=output_shapes, output_dtypes=output_dtypes)

        with tf.device(tf_device):
            session.run(init_op)
            outs = session.run(output_tensors, feed_dict)
            tvm.testing.assert_allclose(outs[0], expect, atol=1e-5, rtol=1e-5)


    def gpu_test(session):
        """test function for gpu"""
        export_dir = None
        try:
            export_dir = build_export_graph()
            test_tf_run(session, export_dir, "/gpu:0")
        finally:
            if export_dir is not None:
                os.system("rm -r %s" % export_dir)

    with tf.Session() as session:
        if tvm.runtime.enabled("gpu"):
            logging.info("Test TensorFlow op on gpu kernel")
            gpu_test(session)


if __name__ == "__main__":
    test_use_tvmdso_op()
