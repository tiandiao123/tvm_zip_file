<!--- Licensed to the Apache Software Foundation (ASF) under one -->
<!--- or more contributor license agreements.  See the NOTICE file -->
<!--- distributed with this work for additional information -->
<!--- regarding copyright ownership.  The ASF licenses this file -->
<!--- to you under the Apache License, Version 2.0 (the -->
<!--- "License"); you may not use this file except in compliance -->
<!--- with the License.  You may obtain a copy of the License at -->

<!---   http://www.apache.org/licenses/LICENSE-2.0 -->

<!--- Unless required by applicable law or agreed to in writing, -->
<!--- software distributed under the License is distributed on an -->
<!--- "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY -->
<!--- KIND, either express or implied.  See the License for the -->
<!--- specific language governing permissions and limitations -->
<!--- under the License. -->

<img src=https://raw.githubusercontent.com/apache/tvm-site/main/images/logo/tvm-logo-small.png width=128/> Open Deep Learning Compiler Stack
==============================================
This is private branch of TVM, maintained by MLSys and AML team at Bytedance. We've made few customizations that diverages from master branch:

- SCM build script. MR: https://code.byted.org/data/tvm/merge_requests/3/diffs
- Load TVM DLL from memory on Windows platform. Commit: https://code.byted.org/lab/tvm/commit/f8eed64834743f771378031307126272d54dca8f
- CUDA API wrapper. TVM loads libcuda.so (nvcuda.dll on Windows) immediately when program starts. This patch allows program loads the dynamic library in ad-hoc way. Commit: https://code.byted.org/lab/tvm/commit/066be3d60ccbea116f5b2b9ce59b1c8ab793899e
- Expose GetInputName and GetWeightNames. Expose two new interface from graph runtime. Commit: https://code.byted.org/lab/tvm/commit/bd9be3308fe45bb001b7aadc8e94d5747ae79a0c
- Param file mangling. Commit: https://code.byted.org/lab/tvm/commit/36a86596248ac7e4b019ba19eb9be93d3d3539e4
- TF-OP API. Commit: https://code.byted.org/data/tvm/commit/1a8f879632b8303abca52806c559539b1054aacd
- Legalize tensorcore. Commits: https://code.byted.org/data/tvm/commit/f132c13f594a4d77ac131baf57034e0fa6e09217, https://code.byted.org/data/tvm/commit/41cdaaac916f42b14e374a7da5f0cbe78b4ef8c3
